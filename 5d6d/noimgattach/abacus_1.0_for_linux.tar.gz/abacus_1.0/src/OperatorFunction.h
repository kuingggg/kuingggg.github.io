// 
#ifndef _OPERATORFUNCTION_H_
#define _OPERATORFUNCTION_H_
#include "includes.h"

namespace zhcosin
{

using std::vector;


// + operator
double plus(const vector<double> &numList);

// - operator
double subtract(const vector<double> &numList);

// - operator
double opposite(const vector<double> &numList);

// * operator
double multiply(const vector<double> &numList);

// / operator
double divide(const vector<double> &numList);

// % operator
double mod(const vector<double> &numList);

// abs operator
double abs(const vector<double> &numList);

// pow operator
double pow(const vector<double> &numList);

// exp operator
double exp(const vector<double> &numList);

// log operator
double log(const vector<double> &numList);

// ln operator
double ln(const vector<double> &numList);

// sqrt operator
double sqrt(const vector<double> &numList);

// sin operator
double sin(const vector<double> &numList);

// cos operator
double cos(const vector<double> &numList);
	
// cos operator
double tan(const vector<double> &numList);

// arcsin operator
double arcsin(const vector<double> &numList);

// arccos operator
double arccos(const vector<double> &numList);

// arctan operator
double arctan(const vector<double> &numList);

// factorial
double factorial(const vector<double> &numList);

// cb operator
double cb(const vector<double> &numList);

// max operator
double max(const vector<double> &numList);

// min operator
double min(const vector<double> &numList);

// ceil operator
double ceil(const vector<double> &numList);

// floor operator
double floor(const vector<double> &numList);

// sinh operator
double sinh(const vector<double> &numList);

// cosh operator
double cosh(const vector<double> &numList);

// tanh operator
double tanh(const vector<double> &numList);

}


#endif

