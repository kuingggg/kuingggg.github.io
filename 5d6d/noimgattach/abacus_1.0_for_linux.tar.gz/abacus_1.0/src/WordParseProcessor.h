//�ʷ��������ඨ��
#ifndef _WORDPARSEPROCESSOR_H_
#define _WORDPARSEPROCESSOR_H_

#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

using std::string;
using std::list;

class WordParseProcessor
{
public:
	WordParseProcessor();
	~WordParseProcessor(){};
public:
	int Parse(const string &str4Parse,list<ExpressPart*> &container);
public:
	bool IsIdentifier(const string &str4Parse);
	bool IsNumber(const string &str4Parse);
	bool IsOperator(const string &str4Parse);
private:
	int PrepareParse(const string &str4Parse);
	int MainParse(const string &str4Parse,list<ExpressPart*> &container);
	int CompleteParse(list<ExpressPart*> &container);
private:
	bool CheckBracketMath(const string &str);
	int ProcessIdentifier(list<ExpressPart*> &container);
	//string::size_type ParseOutNumber(string &str4Parse,string::size_type ix);
	//string::size_type ParseOutIdentifier(string &str4Parse,string::size_type ix);
	//string::size_type ParseOutOperator(string &str4Parse,string::size_type ix);
};

}

#endif
