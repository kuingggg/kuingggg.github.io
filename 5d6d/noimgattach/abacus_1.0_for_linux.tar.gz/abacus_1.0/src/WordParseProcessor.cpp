#include <iostream>
#include "includes.h"
#include "WordParseProcessor.h"
#include "ExpOperator.h"
#include "ExpNumber.h"
#include "ExpIdentifier.h"
#include "ExpBracket.h"
#include "ExpComma.h"


namespace zhcosin
{

using std::string;
using std::list;
using std::cout;
using std::endl;

WordParseProcessor::WordParseProcessor()
{
	ExpOperator::InitOperatorList();
	ExpNumber::InitSymbConstList();
}

bool WordParseProcessor::CheckBracketMath(const string &str)
{
	if(str.empty()) return false;

	int n=0;
	for(string::size_type ix=0; ix!=str.size(); ix++)
	{
		if('('==str[ix]) n++;
		else if(')'==str[ix])
		{
			if(0>--n) return false;
		}
	}

	return 0==n;
}

//�ʷ�����
//���ܣ�����ƥ���飬��������������ݡ���ʶ�������š�����
int WordParseProcessor::MainParse(const string &str4Parse,list<ExpressPart*> &container)
{
	//cout<<"=========WordParseProcessor::MainParse==========="<<endl;
	if(str4Parse.empty())
	{
		return -1;
	}

	if(!CheckBracketMath(str4Parse))	//���Ų�ƥ��
	{
		cout<<"Word error: The brackets in this express is not match rightly."<<endl;
		return -2;
	}

	if(!ExpOperator::IsInitOperatorList()) ExpOperator::InitOperatorList();
	if(!ExpNumber::IsInitSymbConstList()) ExpNumber::InitSymbConstList();

	string::size_type ix=0;
	while(ix<str4Parse.size())
	{
		if(' ' == str4Parse[ix])
		{
			ix++;
			continue;
		}

		if(0!=isdigit(str4Parse[ix]))	//����
		{
			string::size_type jx;	//��־���Ľ�������һ��λ��
			for(jx=ix+1; jx<=str4Parse.size(); jx++)	//�������Ľ���������һ��λ��
			{
				if(str4Parse.size()!=jx)
				{
					//�ų� 2; ���������������
					if(str4Parse.size()==1+jx)
					{
						if(
							(!IsNumber(str4Parse.substr(ix,jx-ix+1)))
							&&(IsNumber(str4Parse.substr(ix,jx-ix))) 
						  )
						{
							break;
						}
					}

					//��һ�������������ζ��������ݣ��������ݽ���������������Ϊ��ֹ
					//3.67��3.��ʱ�����н������Ӷ��õ�������3
					if(
						(!IsNumber(str4Parse.substr(ix,jx-ix+1)))
						&&(!IsNumber(str4Parse.substr(ix,jx-ix))) 
					  )
					{
						jx--;
						break;
					}
				}
			}
			//cout<<"ExpNumber::"<<str4Parse.substr(ix,jx-ix)<<endl;
			container.push_back(new ExpNumber(str4Parse.substr(ix,jx-ix)));
			ix=jx;
		}
		else if(0!=isalpha(str4Parse[ix]))	//��ĸ
		{
			string::size_type jx;
			for(jx=ix+1; jx<=str4Parse.size(); jx++)
			{
				if(!IsIdentifier(str4Parse.substr(ix,jx-ix)))
				{
					jx--;
					break;
				}
			}
			//cout<<"ExpIdentifier::"<<str4Parse.substr(ix,jx-ix)<<endl;
			container.push_back(new ExpIdentifier(str4Parse.substr(ix,jx-ix)));
			ix=jx;
		}
		else
		{
			if(('('==str4Parse[ix])||(')'==str4Parse[ix]))	//����
			{
				//cout<<"ExpBracket::"<<str4Parse.substr(ix,1)<<endl;
				container.push_back(new ExpBracket(str4Parse.substr(ix,1)));
				ix++;
			}
			else if(','==str4Parse[ix])	//����
			{
				//cout<<"ExpComma::"<<str4Parse.substr(ix,1)<<endl;
				container.push_back(new ExpComma());
				ix++;
			}
			else
			{
				bool isopt=false;
				for(string::size_type jx=str4Parse.size(); jx>ix; jx--)
				{
					if(IsOperator(str4Parse.substr(ix,jx-ix)))
					{
						//cout<<"ExpOperator::"<<str4Parse.substr(ix,jx-ix)<<endl;
						container.push_back(new ExpOperator(str4Parse.substr(ix,jx-ix)));
						ix=jx;
						isopt=true;
						break;
					}
				}
	
				//���������Ϊ���Ϸ�
				if (!isopt)
				{
					//ExpressPart::DestroyVectorOfExpressPartPtr(container);
					cout<<"Word error: The string is not a right component of a express: "<<str4Parse[ix]<<endl;
					return -3;
				}
			}
		}
	} //end while
	return 0;
}

//string::size_type WordParseProcessor::ParseOutNumber(string &str4Parse,string::size_type ix)
//{
	//for(string::size_type jx = ix; jx != str4Parse.size(); jx++)
	//{
	//	if()
	//}
	//return 0;
//}
//string::size_type WordParseProcessor::ParseOutIdentifier(string &str4Parse,string::size_type ix);
//{
//	return 0;
//}
//string::size_type WordParseProcessor::ParseOutOperator(string &str4Parse,string::size_type ix);
//{
//	return 0;
//}



bool WordParseProcessor::IsOperator(const string &str4Parse)
{
	return ExpOperator::IsOperator(str4Parse);
}

bool WordParseProcessor::IsNumber(const string &str4Parse)
{
	return ExpNumber::IsNumber(str4Parse);
}

bool WordParseProcessor::IsIdentifier(const string &str4Parse)
{
	return ExpIdentifier::IsIdentifier(str4Parse);
}

int WordParseProcessor::ProcessIdentifier(list<ExpressPart*> &container)
{
	//cout<<"=========WordParseProcessor::ProcessIdentifier========="<<endl;
	if(container.empty()) return -1;

	bool isRight = true;	//ָʾ����ʽ���Ƿ��в���ʶ��ı�ʶ��
	for(list<ExpressPart*>::iterator iter=container.begin(); iter!=container.end(); iter++)
	{
		if(typeid(ExpIdentifier)==typeid(*(*iter)))
		{
			if(IsOperator((*iter)->ReturnStrBody()))
			{
				ExpOperator *opt = new ExpOperator((*iter)->ReturnStrBody());
				delete *iter;
				*iter = opt;
			}
			else if(ExpNumber::IsSymbConstNumber((*iter)->ReturnStrBody()))
			{
				ExpNumber *num = new ExpNumber((*iter)->ReturnStrBody());
				delete *iter;
				*iter = num;
			}
			else	//�Ȳ��������(����),Ҳ���Ƿ��ų����ı�ʶ��
			{
				//cout<<"Error in WordParseProcessor::ProcessIdentifier."<<endl;
				cout<<"Error: The identifier "<<(*iter)->ReturnStrBody()<<" is neither operator nor const number."<<endl;
				isRight = false;
				return -2;
			}
		}
	}
	//if(!isRight) ExpressPart::DestroyVectorOfExpressPartPtr(container);

	return 0;
}

int WordParseProcessor::PrepareParse(const string &str4Parse)
{
	bool isRightBracket = CheckBracketMath(str4Parse);
	if(!isRightBracket)
	{
		cout<<"Word error: The brackets in the express is not match."<<endl;
		return -1;
	}

	return 0;
}

int WordParseProcessor::CompleteParse(list<ExpressPart*> &container)
{
	return ProcessIdentifier(container);
}

int WordParseProcessor::Parse(const string &str4Parse,list<ExpressPart*> &container)
{
	int status_code=0;
	status_code = PrepareParse(str4Parse);
	if(0 != status_code) return -1;

	status_code = MainParse(str4Parse,container);
	if(0 != status_code) return -2;

	status_code = CompleteParse(container);
	if(0 != status_code) return -3;

	return 0;
}

}
