// ��ʶ���ඨ��
#ifndef _IDENTIFIER_H_
#define _IDENTIFIER_H_

#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

class ExpIdentifier : public ExpressPart
{
public:
	ExpIdentifier(){}
	ExpIdentifier(const string &str);
	~ExpIdentifier(){}

public:
	static bool IsIdentifier(const string &str4Parse);
	bool IsLegal();
	bool IsOperator();
	bool IsSymbConstNumber();

private:
	static bool IsIdentifierChar(const char &c);
};

}


#endif
