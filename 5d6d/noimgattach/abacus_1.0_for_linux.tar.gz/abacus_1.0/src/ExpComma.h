// �����ඨ��
#ifndef _EXPCOMMA_H_
#define _EXPCOMMA_H_

#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

class ExpComma : public ExpressPart
{
public:
	ExpComma():ExpressPart(","){}
	~ExpComma(){}

public:
	bool IsLegal(){return ","==strBody;}
	bool IsComma(){return ","==strBody;}
};

}

#endif
