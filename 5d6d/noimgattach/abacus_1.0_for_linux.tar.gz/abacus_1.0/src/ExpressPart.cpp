#include "ExpressPart.h"

namespace zhcosin
{
using namespace std;

int ExpressPart::DestroyVectorOfExpressPartPtr(list<ExpressPart*> &container)
{
	if(container.empty()) return 0;

	for(list<ExpressPart*>::iterator iter=container.begin(); iter!=container.end(); iter++)
	{
		delete *iter;
		*iter=NULL;
	}
	container.clear();

	return 0;
}

}
