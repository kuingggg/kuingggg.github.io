#include "Express.h"
#include "WordParseProcessor.h"
#include "SyntaxParseProcessor.h"

#include "ExpressPart.h"
#include "ExpOperator.h"
#include "ExpNumber.h"
#include "ExpBracket.h"
#include "ExpComma.h"
#include "ExpIdentifier.h"

#include "Computor.h"

namespace zhcosin
{

using namespace std;

Express::Express()
{
}

Express::Express(const string str)
{
	if(0 != WordParse(str)) Destroy();
}

Express::~Express()
{
	Destroy();
}

bool Express::IsLegal()const
{
	return !container.empty();
}

int Express::SyntaxParse()
{
	SyntaxParseProcessor sp;
	int status_code = sp.Parse(container);
	if(0 != status_code) Destroy();
	return status_code;
}

double Express::Value()
{
	Computor cp;
	return cp.Value(container);
}

string Express::ReturnExpStr()const
{
	string str;
	for(list<ExpressPart*>::const_iterator it=container.begin(); it!=container.end(); it++)
	{
		str += (*it)->ReturnStrBody();
		str += " ";
	}
	return str;
}

int Express::WordParse(const string str)
{
	WordParseProcessor wp;
	return wp.Parse(str,container);
}

int Express::Destroy()
{
	if(container.empty()) return 0;

	for(list<ExpressPart*>::iterator iter=container.begin(); iter!=container.end(); iter++)
	{
		delete *iter;
		*iter=NULL;
	}
	container.clear();

	return 0;
}

void Express::ShowContainer()const
{
	cout<<endl<<"===============show================"<<endl;
	if(container.empty())
	{
		cout<<"container is empty."<<endl;
		return;
	}

	for(list<ExpressPart*>::const_iterator iter=container.begin(); iter!=container.end(); iter++)
	{
		if(typeid(*(*iter))==typeid(ExpOperator))
		{
			cout<<"ExpOperator ";
			ExpOperator *opt=dynamic_cast<ExpOperator*>(*iter);
			cout<<((opt->IsCommonOperator())?"Common ":((opt->IsFunctionOperator())?"Function ":"UnknownOpt "))<<opt->Priority()<<endl;
		}
		else if(typeid(*(*iter))==typeid(ExpNumber))
		{
			cout<<"ExpNumber ";
			ExpNumber *num=dynamic_cast<ExpNumber*>(*iter);
			cout<<"value="<<num->Value()<<endl;
		}
		else if(typeid(*(*iter))==typeid(ExpBracket)) cout<<"ExpBracket "<<endl;
		else if(typeid(*(*iter))==typeid(ExpComma)) cout<<"ExpComma "<<endl;
		else if(typeid(*(*iter))==typeid(ExpIdentifier)) cout<<"ExpIdentifier "<<endl;
		else cout<<"unknow ";
	}
	cout<<endl;
}

}
