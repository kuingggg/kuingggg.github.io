#include "Computor.h"

#include "ExpOperator.h"
#include "ExpBracket.h"
#include "ExpNumber.h"

namespace zhcosin
{

using namespace std;

double Computor::Value(list<ExpressPart*> &container)
{
	return ValueStep(container, container.begin(), container.end());
}

double Computor::ValueStep(list<ExpressPart*> &container, const list<ExpressPart*>::iterator ExpBeg, const list<ExpressPart*>::iterator ExpEnd)
{
#ifdef __DEBUG__
	cout<<"********************ValueStep******************"<<endl;
	cout<<"compute: ";
	for(list<ExpressPart*>::iterator it_loop=ExpBeg; it_loop!=ExpEnd; it_loop++)
	{
		cout<<(*it_loop)->ReturnStrBody()<<" ";
	}
	cout<<endl;
#endif
	// �ȴ���һ��������������������ֻ����������ʽֻ��һ����ʱ�����
	if(ExpEnd == next_iterator(ExpBeg))
	{
		ExpNumber *ptr_num = dynamic_cast<ExpNumber*>(*ExpBeg);
		return ptr_num->Value();
	}

	// �����
	list<ExpressPart*>::iterator it_opt = next_iterator(ExpBeg);

	// ��������, �ص��Ǵ����ӱ���ʽ
	int level = 0;
	list<ExpressPart*>::iterator subExpBeg, subExpEnd;
	subExpBeg = ExpBeg;
	subExpEnd = ExpEnd;
	bool isEndSubExp = false;
	for(list<ExpressPart*>::iterator it_loop=next_iterator(it_opt); it_loop!=previous_iterator(ExpEnd); it_loop++)
	{
		if((*it_loop)->ReturnStrBody()=="(")
		{
			if(0==level)
			{
				subExpBeg = it_loop;
			}
			level++;
		}
		else if((*it_loop)->ReturnStrBody()==")")
		{
			level--;
			if(0==level)
			{
				subExpEnd = next_iterator(it_loop);
				// Ϊ���������ӱ���ʽ��ֵ�滻�ӱ���ʽʱ�����ű��������µ�����ʧЧ
				it_loop = previous_iterator(subExpBeg);
				isEndSubExp = true;
			}
		}

		if(isEndSubExp)
		{
			double valueOfSubExp = ValueStep(container, subExpBeg, subExpEnd);
#ifdef __DEBUG__
			cout<<"SubExp: ";
			for(list<ExpressPart*>::iterator it_loop=subExpBeg; it_loop!=subExpEnd; it_loop++)
			{
				cout<<(*it_loop)->ReturnStrBody()<<" ";
			}
			cout<<endl;
			cout<<"valueOfSubExp="<<valueOfSubExp<<endl;
#endif
			// ���ӱ���ʽ��ֵ�滻�ӱ���ʽ
			list<ExpressPart*>::iterator it_del;
			for(list<ExpressPart*>::iterator it_temp=subExpBeg; it_temp!=subExpEnd; it_temp++)
			{
				it_del = it_temp;
				it_temp--;
				delete *it_del;
				*it_del = NULL;
				container.erase(it_del);
			}
			char buffer[50];
			memset(buffer, 0, 50);
			sprintf(buffer, "%f", valueOfSubExp);
			//cout<<"buffer="<<buffer<<endl;
			container.insert(subExpEnd, new ExpNumber(string(buffer)));
			isEndSubExp = false;
		}
	}

	vector<double> parameter;
	ExpNumber *ptr_num = NULL;
	//cout<<"opt: "<<(*it_opt)->ReturnStrBody()<<" parameter:";
	for(list<ExpressPart*>::iterator it_loop=next_iterator(it_opt); it_loop != previous_iterator(ExpEnd); it_loop++)
	{
		ptr_num = dynamic_cast<ExpNumber*>(*it_loop);
		parameter.push_back(ptr_num->Value());
		//cout<<ptr_num->Value()<<" ";
	}
	//cout<<endl;

	ExpOperator *ptr_opt = dynamic_cast<ExpOperator*>(*it_opt);
	OptFunctor function_ptr = ptr_opt->ReturnFunctor();

	return (*function_ptr)(parameter);
}

list<ExpressPart*>::iterator Computor::previous_iterator(list<ExpressPart*>::iterator iter)
{
	list<ExpressPart*>::iterator temp_it=iter;
	return --temp_it;
}

list<ExpressPart*>::iterator Computor::next_iterator(list<ExpressPart*>::iterator iter)
{
	list<ExpressPart*>::iterator temp_it=iter;
	return ++temp_it;
}

}
