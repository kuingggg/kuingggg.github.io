#include "ExpBracket.h"

namespace zhcosin
{

int ExpBracket::upPriority = 10000;

}
