#include "ExpNumber.h"
#include <stdlib.h>

namespace zhcosin
{

using namespace std;

vector<ExpNumber>	ExpNumber::SymbConstList;

ExpNumber::ExpNumber(const string &str):ExpressPart(str)
{
	value=0;
	if(0 != GenerateValue()) strBody.clear();
}

bool ExpNumber::IsInitSymbConstList()
{
	return !SymbConstList.empty();
}

void ExpNumber::InitSymbConstList()
{
	SymbConstList.push_back(ExpNumber("pi",3.1415926535));
	SymbConstList.push_back(ExpNumber("e",2.718281828));
}

bool ExpNumber::IsNumberChar(char c)
{
	bool result = false;

	if( 0 != isdigit(c) )
	{
		result = true;
	}
	else if( '.' == c )
	{
		result = true;
	}

	return result;
}

bool ExpNumber::IsNumber(const string &str4Parse)
{
	if(0 == str4Parse.size()) return false;

	int num_dot = 0; //С�������
	for(string::size_type ix=0; ix!=str4Parse.size(); ix++)
	{
		if('-' == str4Parse[ix])
		{
			if(0 != ix) return false;
		}
		else if(0 != isdigit(str4Parse[ix]))
		{
			continue;
		}
		else if('.'==str4Parse[ix])	
		{
			if( (0==ix) || (str4Parse.size()-1==ix) ) return false;
			if(0 == isdigit(str4Parse[ix-1])) return false;		// С�����ǰһλ��������
			if(1 < ++num_dot) return false;
		}
		else
		{// ���Ϸ��ַ�
			return false;
		}
	}

	return true;
}

bool ExpNumber::IsLegal()const
{
	return ( (IsNumber(strBody)) || (IsSymbConstNumber(strBody)) );
}

int ExpNumber::TransStrToNumber(double &receive, const string &str4Parse)
{
	double value=0;

	if(str4Parse.empty())
	{
		receive = 0;
		return -1;
	}

	bool withOppSgn = false;	//ָʾ�����Ƿ��и���

	string str_temp = str4Parse;
	if('-' == str_temp[0])
	{
		str_temp = str_temp.substr(1, str_temp.size()-1);
		withOppSgn = true;
	}

	if(IsNumber(str_temp)) //��ͨ���ִ���
	{
		value = atof(str_temp.c_str());
	}

	if(withOppSgn)
	{
		value = -value;
	}
	
	receive = value;

	return 0;
}
int ExpNumber::GenerateValue()
{
	if(IsNumber(strBody)) //��ͨ���ִ���
	{
		return TransStrToNumber(this->value, this->strBody)==0 ? 0 : -1;
	}
	else	//���ų�������
	{
		if(!IsInitSymbConstList()) InitSymbConstList();

		for(vector<ExpNumber>::iterator iter=SymbConstList.begin(); iter!=SymbConstList.end(); iter++)
		{
			if(strBody == iter->strBody)
			{
				value = iter->value;
				return 0;
			}
		}
	}

	return -3;	// �Ȳ��ǺϷ���ʵ���ַ�����Ҳ���Ƿ��ų���
}

bool ExpNumber::IsSymbConstNumber(const string& str)
{
	if(!IsInitSymbConstList()) InitSymbConstList();

	if(ExpNumber::SymbConstList.empty()) return false;

	for(vector<ExpNumber>::iterator iter=SymbConstList.begin(); iter!=SymbConstList.end(); iter++)
	{
		if(iter->strBody==str) return true;
	}
	return false;
}


}
