//�﷨�������ඨ��
#ifndef _SYNTAXPARSEPROCESSOR_H_
#define _SYNTAXPARSEPROCESSOR_H_

#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

using namespace std;

class SyntaxParseProcessor
{
public:
	SyntaxParseProcessor(){}
	~SyntaxParseProcessor(){}
public:
	int Parse(list<ExpressPart*> &container);
	int PrepareParse(list<ExpressPart*> &container);
private:
	int ProcessFactorialLocation(list<ExpressPart*> &container);
	int ProcessSubtractAndOpposite(list<ExpressPart*> &container);	//���������븺��
	int processPriorityOfOpt(list<ExpressPart*> &container);
	//int DelComma(list<ExpressPart*> &container);
	int ParseStep(list<ExpressPart*> &container,const list<ExpressPart*>::iterator it_beg,const list<ExpressPart*>::iterator it_end);
	bool CheckBracket(list<ExpressPart*> &container,list<ExpressPart*>::iterator it_beg,list<ExpressPart*>::iterator it_end);
private:
	//��������ص���������
	list<ExpressPart*>::iterator previous_iterator(list<ExpressPart*>::iterator iter);
	list<ExpressPart*>::iterator next_iterator(list<ExpressPart*>::iterator iter);
	bool iterator_compare_lessthan(list<ExpressPart*>& container,list<ExpressPart*>::iterator iter1,list<ExpressPart*>::iterator iter2);
};

}

#endif

