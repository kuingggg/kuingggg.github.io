#include <cmath>
#include "OperatorFunction.h"

namespace zhcosin
{

using std::vector;
using std::pow;
using std::log;
using std::sqrt;
using std::sin;
using std::cos;
using std::tan;
using std::asin;
using std::acos;
using std::atan;
using std::exp;
using std::ceil;
using std::floor;

double opposite(const vector<double> &numList)
{
	if(1!=numList.size()) return 0;

	return -numList[0];
}

// + operator
double plus(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	return numList[0]+numList[1];
}

double subtract(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	return numList[0]-numList[1];
}

double multiply(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	return numList[0]*numList[1];
}

double divide(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	if(numList[1]<0.0000000001 && numList[1]>-0.0000000001)
	{
		return 0;
	}

	return numList[0]/numList[1];
}

double mod(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	return static_cast<int>(numList[0]) % static_cast<int>(numList[1]);
}

double abs(const vector<double> &numList)
{
	if(1 != numList.size()) return 0;

	return numList[0]>0 ? numList[0] : -numList[0];
}

double pow(const vector<double> &numList)
{
	if(2!=numList.size()) return 0;

	return pow(numList[0],numList[1]);
}

double exp(const vector<double> &numList)
{
	return pow(2.718281828,numList[0]);
}

double log(const vector<double> &numList)
{
	if(2 != numList.size())
	{
		return 0;
	}

	return log(numList[0])/log(numList[1]);
}

double ln(const vector<double> &numList)
{
	if(1 != numList.size())
	{
		return 0;
	}

	return log(numList[0]);
}

double sqrt(const vector<double> &numList)
{
	if(1!=numList.size()) return 0;

	return sqrt(numList[0]);
}

double sin(const vector<double> &numList)
{
	if(1!=numList.size()) return 0;

	return sin(numList[0]);
}

double cos(const vector<double> &numList)
{
	if(1!=numList.size()) return 0;

	return cos(numList[0]);
}

double tan(const vector<double> &numList)
{
	if(1!=numList.size()) return 0;

	return tan(numList[0]);
}

double arcsin(const vector<double> &numList)
{
	return asin(numList[0]);
}

double arccos(const vector<double> &numList)
{
	return acos(numList[0]);
}

double arctan(const vector<double> &numList)
{
	return atan(numList[0]);
}


double factorial(const vector<double> &numList)
{
	if(1 != numList.size()) return 0;

	int para = (int)numList[0];
	if(0 == para) return 1;
	
	double result=1;
	for(double n=1; n<=para; n+=1) result*=n;
	return result;
}

// for cb operator 
double cb_compute(const double m, const double n)
{
	if(m<0 || n<=0) return 0;

	if(m>n) return 0;

	if(m>n/2) return cb_compute(n-m,n);

	double fenzi=1, fenmu=1;
	double m_value=m, n_value=n;
	for(double i=0; i<m; i+=1)
	{
		fenzi*=n_value;
		n_value-=1;
		fenmu*=m_value;
		m_value-=1;
	}

	return fenzi/fenmu;
}

// cb operator
double cb(const vector<double> &numList)
{
	if(2 != numList.size()) return 0;

	return cb_compute(numList[0], numList[1]);
}

// max operator
double max(const vector<double> &numList)
{
	if(numList.empty())
	{
		return -1;
	}

	double result=numList[0];
	for(unsigned int i=0; i<numList.size(); i++)
	{
		if(numList[i]>result) result=numList[i];
	}

	return result;
}

// min operator
double min(const vector<double> &numList)
{
	if(numList.empty())
	{
		return -1;
	}

	double result=numList[0];
	for(unsigned int i=0; i<numList.size(); i++)
	{
		if(numList[i]<result) result=numList[i];
	}

	return result;
}

double ceil(const vector<double> &numList)
{
	return ceil(numList[0]);
}

double floor(const vector<double> &numList)
{
	return floor(numList[0]);
}

double sinh(const vector<double> &numList)
{
	double temp = exp(numList[0]);
	return 0.5*(temp-1/temp);
}

double cosh(const vector<double> &numList)
{
	double temp = exp(numList[0]);
	return 0.5*(temp+1/temp);
}

double tanh(const vector<double> &numList)
{
	double temp = exp(numList[0]);
	return (temp-1/temp)/(temp+1/temp);
}

}

