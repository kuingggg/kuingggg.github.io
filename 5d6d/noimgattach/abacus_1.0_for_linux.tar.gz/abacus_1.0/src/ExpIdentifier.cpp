#include "ExpIdentifier.h"
#include "ExpOperator.h"
#include "ExpNumber.h"

namespace zhcosin
{

ExpIdentifier::ExpIdentifier(const string &str):ExpressPart(str)
{
}

bool ExpIdentifier::IsLegal()
{
	return (IsIdentifier(strBody));
}

bool ExpIdentifier::IsIdentifierChar(const char &c)
{
	bool result = false;

	if( 0 != isalpha(c) )
	{
		result = true;
	}
	else if( 0 != isdigit(c) )
	{
		result = true;
	}

	return result;
}

bool ExpIdentifier::IsIdentifier(const string &str4Parse)
{
	if( 0 == str4Parse.size() ) return false;

	if( 0 == isalpha(str4Parse[0]) ) return false;  //���ַ�������ĸ�����Ǳ�ʶ��

	for(string::size_type ix=0; ix!=str4Parse.size(); ix++)
	{
		if( false == IsIdentifierChar(str4Parse[ix]) ) return false;
	}
	return true;
}

bool ExpIdentifier::IsOperator()
{
	return ExpOperator::IsOperator(strBody);
}

bool ExpIdentifier::IsSymbConstNumber()
{
	return ExpNumber::IsSymbConstNumber(strBody);
}

}
