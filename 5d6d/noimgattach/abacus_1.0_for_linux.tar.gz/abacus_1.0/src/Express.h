//����ʽ�ඨ��
#ifndef _EXPRESS_H_
#define _EXPRESS_H_
#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

using std::string;
using std::list;

class Express
{
public:
	Express();
	Express(const string str);
	~Express();
public:
	int	SyntaxParse();
	double 	Value();
	string	ReturnExpStr()const;
	bool	IsLegal()const;
	int	Destroy();
	void	ShowContainer()const;
private:
	list<ExpressPart*>		container;		// ����ʽ����ɲ����б�
private:
	int	WordParse(const string str);
};

}

#endif

