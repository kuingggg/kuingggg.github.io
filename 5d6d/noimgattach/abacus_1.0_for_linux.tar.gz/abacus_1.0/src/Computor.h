//�������ඨ��
#ifndef _COMPUTOR_H_
#define _COMPUTOR_H_

#include "includes.h"
#include "ExpressPart.h"

namespace zhcosin
{

using std::list;

class Computor
{
public:
	Computor(){}
	~Computor(){}
public:
	double Value(list<ExpressPart*> &container);
private:
	double ValueStep(list<ExpressPart*> &container, const list<ExpressPart*>::iterator ExpBeg, const list<ExpressPart*>::iterator ExpEnd);
private:
	list<ExpressPart*>::iterator previous_iterator(list<ExpressPart*>::iterator iter);
	list<ExpressPart*>::iterator next_iterator(list<ExpressPart*>::iterator iter);

};

}

#endif

