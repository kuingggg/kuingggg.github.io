// Common header files.
#ifndef _INCLUDES_H_
#define _INCLUDES_H_
 
#include <stdio.h>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <list>
#include <cctype>
#include <typeinfo>

#define null 0
//#define __DEBUG__

#endif

