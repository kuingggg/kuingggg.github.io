
#include "ExpOperator.h"
#include "OperatorFunction.h"
#include "ExpIdentifier.h"		//for ExpIdentifier::IsIdentifier in IsCommonOperator and IsFunctionOperator.

namespace zhcosin
{

using std::string;
using std::vector;

vector<ExpOperator>		ExpOperator::OperatorList;
int				ExpOperator::AnyNumbers = 100;

ExpOperator::ExpOperator() 
{
	nNumber		= 0;
	priority	= 0;
	functor		= NULL;
}

ExpOperator::ExpOperator(const string &opt) : ExpressPart(opt/*,expPartTypeOperator*/)
{
	nNumber		= 0;
	priority	= 0;
	functor		= NULL;

	if(!IsInitOperatorList()) InitOperatorList();

	for(vector<ExpOperator>::iterator iter=OperatorList.begin(); iter!=OperatorList.end(); iter++)
	{
		if(opt==iter->strBody)
		{
			nNumber		= iter->nNumber;
			priority	= iter->priority;
			functor		= iter->functor;
			break;
		}
	}

}

bool ExpOperator::IsInitOperatorList()
{
	return !OperatorList.empty();
}

ExpOperator::ExpOperator(const string &opt,const int nNumber,const int priority,OptFunctor functor): ExpressPart(opt/*,expPartTypeOperator*/)
{
	this->nNumber	= nNumber;
	this->priority	= priority;
	this->functor	= functor;
}	

bool ExpOperator::IsLegal()
{
	if(0==nNumber) 		return false;
	if(0==priority) 	return false;
	if(NULL==functor) 	return false;

	return true;
}

int ExpOperator::InitOperatorList()
{
	if(IsInitOperatorList()) return 0;

	OperatorList.push_back(ExpOperator("+",2,1,plus));	
	OperatorList.push_back(ExpOperator("-",2,1,subtract));
	OperatorList.push_back(ExpOperator("-",1,2,opposite));
	OperatorList.push_back(ExpOperator("*",2,2,multiply));
	OperatorList.push_back(ExpOperator("/",2,2,divide));
	OperatorList.push_back(ExpOperator("%",2,2,mod));
	OperatorList.push_back(ExpOperator("abs",1,100,abs));
	OperatorList.push_back(ExpOperator("^",2,3,pow));
	OperatorList.push_back(ExpOperator("pow",2,100,pow));
	OperatorList.push_back(ExpOperator("exp",1,100,exp));
	OperatorList.push_back(ExpOperator("log",2,100,log));
	OperatorList.push_back(ExpOperator("ln",1,100,ln));
	OperatorList.push_back(ExpOperator("sqrt",1,100,sqrt));
	OperatorList.push_back(ExpOperator("sin",1,100,sin));
	OperatorList.push_back(ExpOperator("cos",1,100,cos));
	OperatorList.push_back(ExpOperator("tan",1,100,tan));
	OperatorList.push_back(ExpOperator("arcsin",1,100,arcsin));
	OperatorList.push_back(ExpOperator("arccos",1,100,arccos));
	OperatorList.push_back(ExpOperator("arctan",1,100,arctan));
	OperatorList.push_back(ExpOperator("factorial",1,100,factorial));
	OperatorList.push_back(ExpOperator("!",1,3,factorial));
	OperatorList.push_back(ExpOperator("cb",2,100,cb));
	OperatorList.push_back(ExpOperator("max",AnyNumbers,100,max));
	OperatorList.push_back(ExpOperator("min",AnyNumbers,100,min));
	OperatorList.push_back(ExpOperator("ceil",1,100,ceil));
	OperatorList.push_back(ExpOperator("floor",1,100,floor));
	OperatorList.push_back(ExpOperator("sinh",1,100,sinh));
	OperatorList.push_back(ExpOperator("cosh",1,100,cosh));
	OperatorList.push_back(ExpOperator("tanh",1,100,tanh));

	return 0;
}

bool ExpOperator::IsOperator(const string &str4Parse)
{
	if(!IsInitOperatorList()) InitOperatorList();

	for(vector<ExpOperator>::size_type ix=0; ix!=ExpOperator::OperatorList.size(); ix++)
	{
		if(str4Parse==ExpOperator::OperatorList[ix].strBody) return true;
	}

	return false;
}

bool ExpOperator::IsCommonOperator()
{
	if(!IsLegal()) return false;

	return !ExpIdentifier::IsIdentifier(strBody);
}

bool ExpOperator::IsFunctionOperator()
{
	if(!IsLegal()) return false;

	return ExpIdentifier::IsIdentifier(strBody);
}

}
